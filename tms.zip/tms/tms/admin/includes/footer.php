<div class="copyrights">
	 <p>© 2019 GMS. All Rights Reserved |  <a href="#">GMS</a> </p>
</div>	
